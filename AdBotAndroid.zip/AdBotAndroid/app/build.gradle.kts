plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.adbot"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.adbot"
        minSdk = 30            // takeScreenshot() в службе доступности — Android 11+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("org.opencv:opencv:4.9.0")
}
