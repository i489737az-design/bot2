package com.example.adbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.opencv.android.OpenCVLoader
import java.util.concurrent.Executors

class BotService : AccessibilityService() {

    companion object { var instance: BotService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var status: TextView? = null

    private var running = false
    private var busy = false
    private var lastWatch = 0L
    private var cWatch = 0
    private var cClose = 0
    private var lastMsg = ""
    private var nextClose = 0L   // когда в следующий раз искать крестик

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try { step() } catch (e: Exception) { lastMsg = "Ошибка: ${e.message}"; refresh() }
            handler.postDelayed(this, prefs().getInt("interval", 1000).toLong())
        }
    }

    private fun prefs() = getSharedPreferences("bot", MODE_PRIVATE)

    override fun onServiceConnected() {
        instance = this
        OpenCVLoader.initLocal()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stop(); instance = null
        overlay?.let { wm.removeView(it) }; overlay = null
        return super.onUnbind(intent)
    }

    // ── управление ──
    fun start() { if (running) return; running = true; lastMsg = "Запущен"; refresh(); handler.post(tick) }
    fun stop() { running = false; handler.removeCallbacks(tick); lastMsg = "Остановлен"; refresh() }

    // ── один шаг бота ──
    private fun step() {
        if (busy) return
        val now = SystemClock.elapsedRealtime()
        val waitMs = prefs().getInt("wait", 20) * 1000L
        val root = rootInActiveWindow

        // 1) кнопка «Смотреть» (по тексту элемента)
        if (root != null && now - lastWatch > waitMs) {
            val words = prefs().getString("watch", "смотреть,посмотреть,watch")!!
                .split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            val n = findNode(root) { matchWatch(it, words) }
            if (n != null) {
                tap(n); cWatch++; lastWatch = now; nextClose = now + waitMs; lastMsg = "Нажал «Смотреть»"; refresh(); return
            }
        }

        // 2) крестик: первая проверка через «wait» сек. после «Смотреть»,
        //    если не найден — повторная проверка через «recheck» сек.
        if (now < nextClose) return
        nextClose = now + prefs().getInt("recheck", 5) * 1000L
        if (root != null) {
            val c = findNode(root) { matchClose(it) }
            if (c != null) {
                tap(c); cClose++; lastWatch = 0; nextClose = 0
                lastMsg = "Закрыл (по элементу)"; refresh(); return
            }
        }
        // 3) ИИ: ищем крестик на скриншоте
        if (prefs().getBoolean("ai", true)) screenshotDetect()
        else { lastMsg = "Крестик не найден, повтор позже"; refresh() }
    }

    private fun screenshotDetect() {
        busy = true
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)!!
                    val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    val hits = Detector.findClose(bmp, resources.displayMetrics.density)
                    if (hits.isEmpty()) handler.post { lastMsg = "Крестик не найден, повтор позже"; refresh() }
                    if (hits.isNotEmpty()) {
                        val h = hits[0]
                        handler.post {
                            gesture(h.x.toFloat(), h.y.toFloat())
                            cClose++; lastWatch = 0; nextClose = 0
                            lastMsg = "Закрыл (ИИ %.2f)".format(h.score); refresh()
                        }
                    }
                } catch (e: Exception) {
                    handler.post { lastMsg = "Ошибка: ${e.message}"; refresh() }
                } finally { busy = false }
            }
            override fun onFailure(errorCode: Int) { busy = false }
        })
    }

    // ── поиск элементов ──
    private fun label(n: AccessibilityNodeInfo): String =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).trim().lowercase()

    private fun matchWatch(n: AccessibilityNodeInfo, words: List<String>): Boolean {
        val t = label(n)
        return t.isNotEmpty() && t.length <= 40 && words.any { t.contains(it) }
    }

    private fun matchClose(n: AccessibilityNodeInfo): Boolean {
        val t = label(n)
        if (t.isEmpty() || t.length > 25) return false
        if (t in setOf("x", "×", "✕", "✖", "close", "закрыть")) return true
        return listOf("закрыть", "close", "пропустить", "skip", "dismiss").any { t.contains(it) }
    }

    private fun findNode(n: AccessibilityNodeInfo, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n.isVisibleToUser && pred(n)) return n
        for (i in 0 until n.childCount) {
            val ch = n.getChild(i) ?: continue
            findNode(ch, pred)?.let { return it }
        }
        return null
    }

    // ── нажатия ──
    private fun tap(node: AccessibilityNodeInfo) {
        var p: AccessibilityNodeInfo? = node
        while (p != null && !p.isClickable) p = p.parent
        if (p != null && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        val r = Rect(); node.getBoundsInScreen(r)
        gesture(r.exactCenterX(), r.exactCenterY())
    }

    private fun gesture(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    // ── плавающая панель управления ──
    private fun refresh() {
        status?.text = (if (running) "● Работает" else "● Стоп") + "  👁$cWatch  ✖$cClose\n$lastMsg"
    }

    private fun showOverlay() {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC202020.toInt())
            setPadding(px(8), px(6), px(8), px(6))
        }
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; text = "● Стоп" }
        status = tv
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bStart = Button(this).apply { text = "▶"; setOnClickListener { start() } }
        val bStop = Button(this).apply { text = "■"; setOnClickListener { stop() } }
        row.addView(bStart, LinearLayout.LayoutParams(px(60), px(44)))
        row.addView(bStop, LinearLayout.LayoutParams(px(60), px(44)))
        box.addView(tv); box.addView(row)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px(8); y = px(160) }

        // перетаскивание панели за текст статуса
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }
        wm.addView(box, lp)
        overlay = box
    }
}
