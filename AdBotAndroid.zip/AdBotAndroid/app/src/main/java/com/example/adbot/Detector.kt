package com.example.adbot

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

/** «ИИ»-детектор крестиков на компьютерном зрении (OpenCV): ищет маленькие квадратные
 *  объекты с двумя диагональными линиями (~+45° и ~-45°). Работает на любых крестиках. */
object Detector {
    data class Hit(val score: Double, val x: Int, val y: Int)

    fun findClose(bmp: Bitmap, density: Float, minScore: Double = 0.5): List<Hit> {
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba)
        val gray = Mat(); Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        val edges = Mat(); Imgproc.Canny(gray, edges, 80.0, 200.0)
        Imgproc.dilate(edges, edges, Mat.ones(2, 2, CvType.CV_8U))

        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(edges.clone(), contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val minSz = 8 * density
        val maxSz = 48 * density
        val W = bmp.width.toDouble(); val H = bmp.height.toDouble()
        val hits = ArrayList<Hit>()

        for (c in contours) {
            val r = Imgproc.boundingRect(c)
            if (r.width < minSz || r.height < minSz || r.width > maxSz || r.height > maxSz) continue
            if (abs(r.width - r.height) > 0.35 * max(r.width, r.height)) continue
            val roi = edges.submat(r)
            var sc = xScore(roi)
            if (sc <= 0) continue
            val cx = r.x + r.width / 2; val cy = r.y + r.height / 2
            val edgeDist = minOf(cx.toDouble(), W - cx, cy.toDouble(), H - cy) / max(W, H)
            sc *= 1.0 + max(0.0, 0.3 - edgeDist)   // бонус за близость к краю экрана
            if (sc >= minScore) hits.add(Hit(sc, cx, cy))
        }
        rgba.release(); gray.release(); edges.release()
        return hits.sortedByDescending { it.score }
    }

    private fun xScore(roi: Mat): Double {
        val lines = Mat()
        val w = roi.cols(); val h = roi.rows()
        Imgproc.HoughLinesP(roi, lines, 1.0, Math.PI / 180, 8, min(w, h) * 0.4, 3.0)
        var pos = 0; var neg = 0
        for (i in 0 until lines.rows()) {
            val l = lines.get(i, 0)
            val x1 = l[0]; val y1 = l[1]; val x2 = l[2]; val y2 = l[3]
            if (x1 == x2) continue
            var ang = Math.toDegrees(atan2(y2 - y1, x2 - x1))
            if (ang > 90) ang -= 180
            if (ang < -90) ang += 180
            val mx = (x1 + x2) / 2; val my = (y1 + y2) / 2
            if (abs(mx - w / 2.0) > w * 0.3 || abs(my - h / 2.0) > h * 0.3) continue
            if (ang in 30.0..60.0) pos++ else if (ang in -60.0..-30.0) neg++
        }
        lines.release()
        return if (min(pos, neg) > 0) min(1.0, (pos + neg) / 4.0) else 0.0
    }
}
