package com.example.adbot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.widget.*

class MainActivity : Activity() {

    private lateinit var etWatch: EditText
    private lateinit var etWait: EditText
    private lateinit var etRecheck: EditText
    private lateinit var cbAi: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("bot", MODE_PRIVATE)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun tv(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, pad / 2, 0, 0) }

        col.addView(tv(
            "1) Включите службу «Ad Bot» в Спец. возможностях.\n" +
            "2) Откройте приложение с рекламой — на экране появится панель ▶ ■.\n" +
            "3) Нажмите ▶. Панель можно перетаскивать за текст."))

        col.addView(Button(this).apply {
            text = "Открыть настройки спец. возможностей"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        col.addView(tv("Слова на кнопке «Смотреть» (через запятую):"))
        etWatch = EditText(this).apply { setText(p.getString("watch", "смотреть,посмотреть,watch")) }
        col.addView(etWatch)

        col.addView(tv("Первый поиск крестика через, сек:"))
        etWait = EditText(this).apply {
            setText(p.getInt("wait", 20).toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        col.addView(etWait)

        col.addView(tv("Если крестика нет — повторить через, сек:"))
        etRecheck = EditText(this).apply {
            setText(p.getInt("recheck", 5).toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        col.addView(etRecheck)

        cbAi = CheckBox(this).apply { text = "ИИ-поиск крестиков на экране"; isChecked = p.getBoolean("ai", true) }
        col.addView(cbAi)

        col.addView(Button(this).apply { text = "Сохранить"; setOnClickListener { save() } })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "▶ Запуск"; setOnClickListener { startBot() } },
            LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "■ Стоп"; setOnClickListener { stopBot() } },
            LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(row)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun save() {
        getSharedPreferences("bot", MODE_PRIVATE).edit()
            .putString("watch", etWatch.text.toString())
            .putInt("wait", etWait.text.toString().toIntOrNull() ?: 20)
            .putInt("recheck", (etRecheck.text.toString().toIntOrNull() ?: 5).coerceAtLeast(1))
            .putBoolean("ai", cbAi.isChecked).apply()
        Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
    }

    private fun startBot() {
        save()
        val s = BotService.instance
        if (s == null) Toast.makeText(this, "Сначала включите службу в Спец. возможностях", Toast.LENGTH_LONG).show()
        else { s.start(); moveTaskToBack(true) }
    }

    private fun stopBot() { BotService.instance?.stop() }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Запуск"); menu.add(0, 2, 1, "Стоп"); menu.add(0, 3, 2, "Спец. возможности")
        return true
    }

    override fun onOptionsItemSelected(i: MenuItem): Boolean {
        when (i.itemId) {
            1 -> startBot(); 2 -> stopBot()
            3 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        return true
    }
}
